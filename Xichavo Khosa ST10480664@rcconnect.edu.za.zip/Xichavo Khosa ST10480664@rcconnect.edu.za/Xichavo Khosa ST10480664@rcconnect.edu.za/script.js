// Shared JavaScript: mobile navigation, project search, gallery lightbox and forms.
document.addEventListener("DOMContentLoaded", () => {
  // Mobile navigation toggle.
  const menuBtn = document.getElementById("menuBtn");
  const navMenu = document.getElementById("navMenu");
  if (menuBtn && navMenu) {
    menuBtn.addEventListener("click", () => {
      const isOpen = navMenu.classList.toggle("open");
      menuBtn.setAttribute("aria-expanded", String(isOpen));
      menuBtn.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
      menuBtn.textContent = isOpen ? "×" : "☰";
    });
  }

  // Filter programme cards as the visitor types.
  const projectSearch = document.getElementById("projectSearch");
  const projectGrid = document.getElementById("projectGrid");
  if (projectSearch && projectGrid) {
    const cards = Array.from(projectGrid.querySelectorAll(".project-card"));
    const searchCount = document.getElementById("searchCount");
    const noProjects = document.getElementById("noProjects");
    projectSearch.addEventListener("input", () => {
      const query = projectSearch.value.trim().toLowerCase();
      let visible = 0;
      cards.forEach(card => {
        const content = `${card.dataset.search || ""} ${card.textContent}`.toLowerCase();
        const match = content.includes(query);
        card.hidden = !match;
        if (match) visible++;
      });
      searchCount.textContent = `Showing ${visible} of ${cards.length} programme areas.`;
      noProjects.hidden = visible !== 0;
    });
  }

  // Gallery lightbox: open a larger, accessible view of a selected illustration.
  const lightbox = document.getElementById("lightbox");
  const lightboxVisual = document.getElementById("lightboxVisual");
  const lightboxCaption = document.getElementById("lightboxCaption");
  const lightboxClose = document.getElementById("lightboxClose");
  let lastGalleryButton = null;
  if (lightbox && lightboxVisual && lightboxCaption && lightboxClose) {
    document.querySelectorAll("[data-lightbox]").forEach(button => {
      button.addEventListener("click", () => {
        lastGalleryButton = button;
        const artClass = button.dataset.art;
        const original = button.querySelector(".gallery-art");
        lightboxVisual.className = `lightbox-visual ${artClass || ""}`;
        lightboxVisual.textContent = original ? original.textContent : "";
        lightboxCaption.textContent = button.dataset.lightbox;
        lightbox.hidden = false;
        lightboxClose.focus();
      });
    });
    const closeLightbox = () => {
      lightbox.hidden = true;
      if (lastGalleryButton) lastGalleryButton.focus();
    };
    lightboxClose.addEventListener("click", closeLightbox);
    lightbox.addEventListener("click", event => {
      if (event.target === lightbox) closeLightbox();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && !lightbox.hidden) closeLightbox();
    });
  }

  // Show an error message beside a form field and set its invalid state.
  function setFieldError(input, messageElement, message) {
    if (!input || !messageElement) return;
    messageElement.textContent = message;
    input.classList.toggle("invalid", Boolean(message));
    input.setAttribute("aria-invalid", String(Boolean(message)));
  }

  function validName(value) {
    return value.trim().length >= 2 && value.trim().length <= 80;
  }
  function validEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim());
  }
  function validMessage(value, min = 10, max = 1500) {
    return value.trim().length >= min && value.trim().length <= max;
  }

  // Enquiry form validates input and shows a relevant front-end response.
  const enquiryForm = document.getElementById("enquiryForm");
  if (enquiryForm) {
    const fields = {
      name: document.getElementById("enqName"),
      email: document.getElementById("enqEmail"),
      phone: document.getElementById("enqPhone"),
      type: document.getElementById("enqType"),
      message: document.getElementById("enqMessage"),
      consent: document.getElementById("enqConsent")
    };
    const response = document.getElementById("enquiryResponse");
    const errors = {
      name: document.getElementById("enqNameError"),
      email: document.getElementById("enqEmailError"),
      phone: document.getElementById("enqPhoneError"),
      type: document.getElementById("enqTypeError"),
      message: document.getElementById("enqMessageError"),
      consent: document.getElementById("enqConsentError")
    };
    const validate = () => {
      let ok = true;
      const checks = [
        ["name", validName(fields.name.value), "Please enter a name between 2 and 80 characters."],
        ["email", validEmail(fields.email.value), "Please enter a valid email address."],
        ["phone", !fields.phone.value.trim() || /^[0-9+() -]{7,20}$/.test(fields.phone.value.trim()), "Please enter a valid phone number."],
        ["type", Boolean(fields.type.value), "Please select an enquiry type."],
        ["message", validMessage(fields.message.value, 10, 1000), "Please enter 10–1,000 characters."],
        ["consent", fields.consent.checked, "Please confirm your information is accurate."]
      ];
      checks.forEach(([key, passes, message]) => {
        if (!passes) ok = false;
        const input = fields[key];
        if (key === "consent") {
          errors[key].textContent = passes ? "" : message;
        } else {
          setFieldError(input, errors[key], passes ? "" : message);
        }
      });
      return ok;
    };
    Object.values(fields).forEach(field => {
      if (field && field.addEventListener) {
        field.addEventListener("input", () => {
          response.textContent = "";
          response.classList.remove("error-response");
        });
      }
    });
    enquiryForm.addEventListener("submit", event => {
      event.preventDefault();
      response.classList.remove("error-response");
      if (!validate()) {
        response.textContent = "Please review the highlighted fields and try again.";
        response.classList.add("error-response");
        const firstInvalid = enquiryForm.querySelector(".invalid, input[type='checkbox']:invalid");
        if (firstInvalid) firstInvalid.focus();
        return;
      }
      const type = fields.type.value;
      let nextStep = "We would review your enquiry and advise you about suitable next steps.";
      if (type === "Volunteering") nextStep = "Your next step would be to discuss your interests, skills and availability.";
      if (type === "Sponsorship" || type === "Donation") nextStep = "Your next step would be to discuss the type of support and how it could benefit community programmes.";
      if (type.includes("support") || type.includes("development") || type.includes("empowerment")) nextStep = "Your next step would be to discuss programme information, availability and the support you need.";
      response.textContent = `Thank you, ${fields.name.value.trim()}. ${nextStep} This is a demonstration only; your enquiry has not been sent or saved.`;
      enquiryForm.reset();
    });
  }

  // Contact form validates the message and prepares a mailto email.
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    const fields = {
      name: document.getElementById("contactName"),
      email: document.getElementById("contactEmail"),
      type: document.getElementById("contactType"),
      message: document.getElementById("contactMessage")
    };
    const errors = {
      name: document.getElementById("contactNameError"),
      email: document.getElementById("contactEmailError"),
      type: document.getElementById("contactTypeError"),
      message: document.getElementById("contactMessageError")
    };
    const response = document.getElementById("contactResponse");
    contactForm.addEventListener("submit", event => {
      event.preventDefault();
      let valid = true;
      const checks = [
        ["name", validName(fields.name.value), "Please enter a name between 2 and 80 characters."],
        ["email", validEmail(fields.email.value), "Please enter a valid email address."],
        ["type", Boolean(fields.type.value), "Please select a message type."],
        ["message", validMessage(fields.message.value, 10, 1500), "Please enter 10–1,500 characters."]
      ];
      checks.forEach(([key, passes, message]) => {
        if (!passes) valid = false;
        setFieldError(fields[key], errors[key], passes ? "" : message);
      });
      response.classList.remove("error-response");
      if (!valid) {
        response.textContent = "Please correct the highlighted fields before preparing your email.";
        response.classList.add("error-response");
        const firstInvalid = contactForm.querySelector(".invalid");
        if (firstInvalid) firstInvalid.focus();
        return;
      }
      // Replace this placeholder with the organisation's approved email before deployment.
      const recipient = "info@example.org";
      const subject = `Website message: ${fields.type.value}`;
      const body = `Name: ${fields.name.value.trim()}\nEmail: ${fields.email.value.trim()}\nMessage type: ${fields.type.value}\n\nMessage:\n${fields.message.value.trim()}`;
      response.textContent = "Your details passed validation. Opening your email application with the message prepared. Please replace the placeholder recipient before publishing.";
      window.location.href = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    });
  }

  // Read an optional programme interest from the projects page link.
  const enquiryType = document.getElementById("enqType");
  if (enquiryType) {
    const params = new URLSearchParams(window.location.search);
    const interest = params.get("interest");
    if (interest) {
      const matchingOption = Array.from(enquiryType.options).find(option => option.text.toLowerCase() === interest.toLowerCase());
      if (matchingOption) enquiryType.value = matchingOption.value;
    }
  }
});
