# Hope Community Development Centre Website

## Project overview
This responsive multi-page website was developed as an academic front-end project for a fictional South African non-profit organisation, Hope Community Development Centre. It presents the organisation's history, mission, vision, programme areas and ways for community members, volunteers, donors, sponsors and partners to make enquiries.

## Pages
- `index.html` — introduction, focus areas and calls to action
- `about.html` — history, mission, vision and values
- `projects.html` — programme cards with live search/filter
- `gallery.html` — visual gallery with an accessible lightbox
- `enquiry.html` — enquiry form with JavaScript validation and response messages
- `contact.html` — general contact form, mailto preparation and OpenStreetMap embed

## Technologies
- HTML5 semantic elements
- CSS3, responsive breakpoints and reduced-motion support
- Vanilla JavaScript for navigation, project filtering, gallery lightbox and client-side form validation
- OpenStreetMap embed for a location-based feature
- Git and GitHub for version control
- Netlify or GitHub Pages for free static hosting

## Run locally
1. Download and extract the project folder.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the Live Server extension.
4. Check the navigation and forms at desktop, tablet and mobile widths.

## Important before deployment
- This is a fictional organisation for an academic project.
- Replace `info@example.org`, placeholder telephone details, and the sample Pretoria map with approved organisation contact details and location(s).
- Replace `https://example.org` in each canonical URL, `robots.txt` and `sitemap.xml` with the actual deployed domain.
- The enquiry form currently validates input and displays a demonstration response; it does not save or transmit submissions.
- The contact form uses `mailto:`. It opens the visitor's configured email application but does not send email automatically. A backend or form service is needed for reliable server-side email handling.
- The gallery visuals are CSS illustrations and emoji placeholders. Replace them with approved photos and descriptive filenames/alt text before a real launch.
- Add only accurate, confirmed locations and programme information.

## SEO and accessibility
- Unique title, meta description and keywords on each page.
- Semantic headings, descriptive link text and image/visual labels.
- Responsive layout and keyboard-visible focus states.
- Skip link, accessible mobile menu labels and lightbox Escape-to-close support.
- `robots.txt` and `sitemap.xml` included as templates.

## Development timeline (proposal)
Approximate duration: 10–12 weeks for research, planning, design, development, testing and documentation.

## Estimated budget (proposal)
Estimated initial budget: R3,000–R8,000 depending on domain, hosting and maintenance. Free static hosting may reduce hosting costs for this front-end demonstration.

## Changelog
### 2026-10-29 — Part 3 functionality and SEO
- Built a consistent multi-page site from the supplied HTML starter structure and replaced unrelated furniture/bakery branding with Hope Community Development Centre content.
- Added a responsive mobile navigation toggle with an accessible expanded state.
- Added live project search and result count on the Projects page.
- Added gallery lightbox interactions with click-to-open, close button, backdrop close and Escape-key support.
- Added enquiry form client-side validation, field-specific error messages and a programme-related demonstration response.
- Added contact form validation and `mailto:` email preparation using a placeholder recipient.
- Added page-specific titles, descriptions, keywords, canonical URL templates and robots directives.
- Added `robots.txt`, `sitemap.xml`, responsive styles, focus states and reduced-motion support.
- Added an OpenStreetMap embed as a location-based feature; the displayed Pretoria-area map is a placeholder and must be checked against the real organisation location.
- Documented placeholder contact details, front-end form limitations and deployment changes needed before publication.

## References
GitHub (2026) *Getting started with Git*. Available at: https://docs.github.com/en/get-started/learning-to-code/getting-started-with-git (Accessed: 29 October 2026).

GitHub (2026) *Using Git*. Available at: https://docs.github.com/en/get-started/using-git (Accessed: 29 October 2026).

GitHub (2026) *Creating a repository for your project on GitHub*. Available at: https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository (Accessed: 29 October 2026).

Mozilla Developer Network (2026) *HTML: HyperText Markup Language*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML (Accessed: 29 October 2026).

Mozilla Developer Network (2026) *HTML elements reference*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Element (Accessed: 29 October 2026).

Mozilla Developer Network (2026) *Client-side form validation*. Available at: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation (Accessed: 29 October 2026).

OpenStreetMap contributors (2026) *OpenStreetMap*. Available at: https://www.openstreetmap.org/ (Accessed: 29 October 2026).

Netlify (2026) *Deploying a website*. Available at: https://docs.netlify.com/ (Accessed: 29 October 2026).

Note: Check the actual page titles and publication/update dates of sources before final academic submission and follow your lecturer's required referencing style.
